{
	"ID": 1,
	"Title": "P31 DSL Blog",
	"Url": "127.0.0.1",
	"Template": 1,
	"Keywords": "local, daheim, privat",
	"Description": "Der Testblog wie er auf meinem Heimrechner aussehen soll",
	"Slogan": "Home Sweet Home",
	"Server": 2,
	"Rubrics": {}
}